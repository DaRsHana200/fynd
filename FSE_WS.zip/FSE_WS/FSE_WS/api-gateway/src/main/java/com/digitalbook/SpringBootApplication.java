package com.digitalbook;

public @interface SpringBootApplication {

}
