package com.digitalbook.author.exception;

public class AuthorException extends Exception {

	public AuthorException(String string) {
		// TODO Auto-generated constructor stub
		
		
	}

	public AuthorException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AuthorException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public AuthorException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AuthorException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
