package com.digitalbook;

import java.time.LocalDate;


//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;






@SpringBootApplication
public class AutherServiceApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(AutherServiceApplication.class, args);
		System.out.println("AutherService running");
	}

	

}
