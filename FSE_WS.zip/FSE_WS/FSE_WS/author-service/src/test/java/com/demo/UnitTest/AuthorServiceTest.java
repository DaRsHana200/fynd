package com.demo.UnitTest;

import static org.hamcrest.CoreMatchers.any;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalbook.author.entities.Author;
import com.digitalbook.author.entities.AuthorBook;
import com.digitalbook.author.repositories.AuthorBookRepository;
import com.digitalbook.author.repositories.AuthorRepository;
import com.digitalbook.author.service.AuthorService;

@ExtendWith(MockitoExtension.class)
class AuthorServiceTest {
	
	@InjectMocks
	AuthorService authorService;
	
	@Mock
	AuthorBookRepository arepo;  
	
	@Test
	void test() {
		List<AuthorBook> list=new ArrayList<AuthorBook>();
		AuthorBook a=new AuthorBook();
		a.setA_category("historical");
		a.setA_bookid(1);
		a.setA_name("ramayan");
		a.setA_price(100);
		a.setA_isblock(false);
		a.setA_publishdate("22/03/2022");
		a.setA_publisher("nakul");
		list.add(a);
		
		/*
		a.setAid(1);
       a.setUsername("mayuri");     
       a.setPassword("123");
       */
		
		when(arepo.findAll()).thenReturn(list);
		List<AuthorBook> lst=authorService.findAll();
		assertEquals(1,lst.get(0).getA_bookid());
		
	}

}
